﻿namespace M6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var set1 = Console.ReadLine().Split(' ').Select(int.Parse).ToHashSet();
            var set2 = Console.ReadLine().Split(' ').Select(int.Parse).ToHashSet();
            Console.WriteLine("Сечение: " + string.Join(" ", set1.Intersect(set2)));
            Console.WriteLine("Обединение: " + string.Join(" ", set1.Union(set2)));
            Console.WriteLine("Разлика: " + string.Join(" ", set1.Except(set2)));
            Console.WriteLine("Сбор: " + set1.Concat(set2).Sum());
        }
    }
}
