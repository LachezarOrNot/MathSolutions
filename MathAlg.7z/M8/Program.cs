﻿namespace M8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var rnd = new Random();
            var counts = new int[6];
            for (int i = 0; i < 100; i++)
                counts[rnd.Next(6)]++;
            for (int i = 0; i < 6; i++)
                Console.WriteLine($"{i + 1}: {counts[i]}");
        }
    }
}
