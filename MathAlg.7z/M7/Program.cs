﻿using System.Numerics;

namespace M7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int a1 = int.Parse(Console.ReadLine());
            int a2 = int.Parse(Console.ReadLine());
            BigInteger Factorial(int x)
            {
                BigInteger r = 1;
                for (int i = 2; i <= x; i++) r *= i;
                return r;
            }
            BigInteger P = Factorial(a1);
            BigInteger C = Factorial(a1) / (Factorial(a2) * Factorial(a1 - a2));
            BigInteger V = Factorial(a1) / Factorial(a1 - a2);
            Console.WriteLine($"{P} {C} {V}");
        }
    }
}
